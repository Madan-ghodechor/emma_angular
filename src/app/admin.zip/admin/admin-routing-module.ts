import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Login } from './login/login';
import { Dashboard } from './dashboard/dashboard';
import { authGuard } from './auth-guard';
import { Header } from './layout/header/header';

const routes: Routes = [
  {
    path: '',
    component: Login
  },
  {
    path: '',
    component: Header,
    canActivate: [authGuard],
    children: [
      { path: 'dashbord', component: Dashboard }
    ]
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}